import java.applet.*;
import java.awt.*;
public class appletdemo extends Applet {
    public void paint(Graphics g) {
        g.drawString("this is code from java",10,10);
    }
}