# executable-one
code related to the blog post: Java 8 : How to create fatJAR without IDE, command-line

