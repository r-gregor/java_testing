package com.exec.one.service;

public class MagicService {

    private final String message;
    public MagicService(){
        this.message = "Magic Message";
    }

    public String getMessage(){
        return message;
    }

}
