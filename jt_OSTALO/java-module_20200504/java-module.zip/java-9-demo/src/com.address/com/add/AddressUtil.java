package com.add;
public class AddressUtil {
   public String getCity(int id) {
	   return id + "- Noida" ;
   }
}