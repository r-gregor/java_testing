package com.emp;
import com.add.AddressUtil;
public class EmpMain {
   public static void main(String[] args) {
     AddressUtil ob = new AddressUtil();
     System.out.println(ob.getCity(100));
   }
}